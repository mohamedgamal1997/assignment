//  (1) // var num = prompt("enter your number") 
// console.log(num)

  //  (2) // var num = prompt("enter your number")
// if (num % 3==0 && num % 4 ==0  ){
//     console.log("yes")
// }

// else {
//     console.log("no ")
// }



 //  (3) // var num1 = prompt("enter your number")
// var num2 = prompt("enter your second number")
// if(num1 > num2){ 
//     console.log(num1)
// }
// else if (num2 > num1){ 
//     console.log(num2)
// }


 //  (4) // var num = prompt("enter your number")
// if (num > 0) { 
//     console.log(" positive"); 
// } 
// else if (num < 0) { 
//     console.log(" negative"); 
// } 

  //  (6) // var num = prompt("enter your number")
//  if (num % 2 ==0  ){
//     console.log("even")
    
//  }
//  else{
//     console.log("odd")
    
//  }
 

 //  (7) // var x = prompt("enter character")
// if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u') 
// {
//      console.log("vowel")
//   }
//   else{
//      console.log("Consonant")
     
//   }

//  (8)
// var num = prompt("enter number")
// for(var i = 1 ; i <=num ;i++ ){
//     console.log(i)
// }
//  (9)
// var num = prompt("number")
//  for ( var i =1 ; i <= 12 ; i++     )
// { console.log( num * i); }


//  (10)
// var n = prompt("any") 

// var power = 3  
// var num = 1; 
// for (var i = 0; i < power; ++i) { 
// 	num = num * n; 
// } 
// console.log(num);

//  (11)
// 
// function calculatePercentage(physics, chemistry, biology, mathematics, computer) {
//     var totalMarks = 500; 
//     var obtainedMarks = physics + chemistry + biology + mathematics + computer;
//     var percentage = (obtainedMarks / totalMarks) * 100;
//     return percentage;
// }


// function calculateGrade(percentage) {
//     if (percentage >= 90) {
//         return 'A';
//     } else if (percentage >= 80) {
//         return 'B';
//     } else if (percentage >= 70) {
//         return 'C';
//     } else if (percentage >= 60) {
//         return 'D';
//     } else {
//         return 'F';
//     }
// }


// var physicsMarks = 
// prompt('Enter Physics marks:');
// var chemistryMarks = prompt('Enter Chemistry marks:');
// var biologyMarks = prompt('Enter Biology marks:');
// var mathematicsMarks = prompt('Enter Mathematics marks:');
// var computerMarks = prompt('Enter Computer marks:');


// var percentage = calculatePercentage(physicsMarks, chemistryMarks, biologyMarks, mathematicsMarks, computerMarks);


// var grade = calculateGrade(percentage);

// console.log(`Percentage: ${percentage.toFixed(2)}%`);
// console.log(`Grade: ${grade}`);









